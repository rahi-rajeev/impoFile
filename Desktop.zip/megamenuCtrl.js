/*
*@description : megamenu 
*@Author : SMOOTHGRAPH CONNECT PVT LRD.
*/
//controller section
;(function($_ang){

	//variable section
	$scope.treeObj ={
		main_tree_data : [],
		clone_tree_data : [],
		icon_lib : [],
		menu_wrapper : {
			"name" : 'we',
			"id" : "dad",
			"title" : "xxx",
		},
		cate_tree : [],
		LinkMenuType : [
		  {
            'id'    : '1',
            'title' : 'Product Category',
            'class' : 'glyphicon glyphicon-gift'
          },
          {
            'id'    : '2',
            'title' : 'Blog Category',
            'class' : 'glyphicon glyphicon-list'
          },
          {
            'id'    : '3',
            'title' : 'System Page Link',
            'class' : 'glyphicon glyphicon-edit'
          },
          {
            'id'    : '4',
            'title' : 'Page Link',
            'class' : 'glyphicon glyphicon-open-file'
          },
          {
            'id'    : '5',
            'title' : 'Product Link',
            'class' : 'glyphicon glyphicon-cd'
          },
          {
            'id'    : '6',
            'title' : 'Blog Link',
            'class' : 'glyphicon glyphicon-book'
          }
		],
		systmePageLinks : [
		  {'title':'Homepage','url':site_url},
          {'title':'Listing Page','url':site_url+'/category/lorem-ipsum'},
          {'title':'Product Detail Page','url':site_url+'/product/panty/MC1509002649FG'},
          {'title':'Cart Page','url':site_url+'/cart'},
          {'title':'Checkout Page','url':site_url+'/cart'},
          {'title':'Thank You Page','url':site_url+'/thanks'},
          {'title':'Login Page','url':site_url+'/login'},
          {'title':'Forgot Password Page','url':site_url+'/login'},
          {'title':'Brand Listing Page','url':site_url+'/product/panty/MC1509002649FG'},
          {'title':'Take it fast','url':site_url},
          {'title':'Ok Page','url':site_url}
		],
	};

	//mega menu ui tree option section
	$scope.megaMenuTreeOption = {
		//Listen on drop node in droped container
		dropped : function(event){
			//
		},

		//Listen on node move
		dragMove : function(){
			//
		},
		//listen on before drop
		beforeDrop: function(event){

		}
	},



	//broadcast event 
	$scope.collapseAll = function () {
      $scope.$broadcast('angular-ui-tree:collapse-all');
    };

    $scope.expandAll = function () {
       $scope.$broadcast('angular-ui-tree:expand-all');
    };

    $scope.openItem = function($event, node, e, index){
        $event.preventDefault();        
        var wraper_id = 'item_'+e+'_'+index;
        node.toggle_class = !node.toggle_class;
        $('#'+wraper_id).toggle(200); 
        $scope.objId=e;
        $scope.objType='';
        $scope.objType=index;
    };

    $scope.openChildItem = function($event, node, e, index, parentNodeId, currentNodeId){        
        node.toggle_class = !node.toggle_class;
        $('#item_'+e+'_'+index+'_'+parentNodeId+'_'+currentNodeId).toggle(200);         
        $scope.objId=e;
        $scope.objType='';
        $scope.objType=index;
    }; 


})(window.angular);

//serives section
;(function(ng){
	ng.module("sabinaAdminApp").service('megaService', megaServiceHandeler);

	megaServiceHandeler function(){
		var self = this;

		function checkAlowedType(node, parentNode){
			//
		};

		function generateUniqueId(node, nodeCollection){
			//
		};

		function pushInParentNode(node, parentNode){
			//
		};

		function iconManagenet(node, iconId, action){
			//
		};

		function removeNode(node, parentNode){

		};

		return{
			checkAlowedType : checkAlowedType,
			generateUniqueId :generateUniqueId,
			pushInParentNode : pushInParentNode,
			iconManagenet : iconManagenet,
			iconManagenet : iconManagenet,
			removeNode : removeNode,			
		};
	};
})(window.angular);

